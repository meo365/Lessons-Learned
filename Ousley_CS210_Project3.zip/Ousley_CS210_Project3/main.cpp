// Martin Ousley
// CS 210 Mod 7 Project 3
// 8/24/2025

#include <iostream> // for standard output cout
#include <string>      // for string usage
#include <fstream>   // for file input and output
#include <map>        // for tracking occurances
#include <chrono>    // for date and time for backup logs
#include <ctime>      // for printing chrono time
#include <iomanip>  // for string formatting

using namespace std;

// variables
string menuChoice = "";
string itemChoice ="";
string inputFile = "CS210_Project_Three_Input_File.txt";
string outputFile = "frequency.dat";
string menuOptions[5] = {
    "Please select and enter an option number [1-4]\n"
    "Option 1: Enter single item and get the number of occurances",
    "Option 2: Get all item occurances in input file",
    "Option 3: Get all item occurances in histogram format",
    "Option 4: Exit"
    };

// function declarations
// I like put function declarations at the top to help ensure my other functions can find the code and put them below main
void countItems();
void displayMenu();
int getInstancesOfWord(string userWord);
void writeToBackup(string userItem, int itemCount);
void writeSectionBackupLabel(string label);
void countItemsHistogram();

// TODO (rever#1#): Create a data file, with the naming convention frequency.dat, for backing up your accumulated data.
// The frequency.dat file should include every item (represented by a word) paired with the number of times that item
// appears in the input file.

int main()
{
    // Loop continously until exit option is chosen.
    while (menuChoice != "4")
    {
        displayMenu();
        cout << "[1-4]: ";
        getline(cin, menuChoice);
        if (menuChoice == "1")
        {
                cout << "Please enter item to search for \(ex: Potatoes\): ";
                getline(cin, itemChoice);
                cout << endl << itemChoice << ": " << getInstancesOfWord(itemChoice) << endl << endl;
        }
        else if (menuChoice == "2")
        {
            cout << endl;
            countItems();
            cout << endl;
        }
        else if (menuChoice == "3")
        {
            cout << endl;
            countItemsHistogram();
            cout << endl;
        }
        else if (menuChoice == "4")
        {
            cout << "\nExiting..." << endl;
        }
        else
        {
            cout << "Invalid Menu Option, Please enter a single digit 1 - 4 numerically." << endl;
        }
    }
    return 0;
}

// Function Definitions
// count all items and print pairs to screen.
void countItems()
{
        ifstream inFS; // input file stream
        map<string, int> wordCounts; // map of word and int for count
        string currentWord = ""; // current word when parsing
        inFS.open(inputFile); // open the file

        // verify file opened
        if (!inFS.is_open())
        {
            cout << "Error: Could not open " << inputFile << "." << endl;
        }
        while(inFS >> currentWord)
        {
            // Increment current word in map
            wordCounts[currentWord]++;
        }

        // close file
        inFS.close();

        // print word counts & backup results
        writeSectionBackupLabel("LOG TIME: ");
        for (const auto& pair : wordCounts)
        {
            cout << pair.first << " " << pair.second << endl;
            writeToBackup(pair.first, pair.second);
        }
}

void countItemsHistogram()
{
        ifstream inFS; // input file stream
        map<string, int> wordCounts; // map of word and int for count
        string currentWord = ""; // current word when parsing
        inFS.open(inputFile); // open the file

        // verify file opened
        if (!inFS.is_open())
        {
            cout << "Error: Could not open " << inputFile << "." << endl;
        }
        while(inFS >> currentWord)
        {
            // Increment current word in map
            wordCounts[currentWord]++;
        }

        // close file
        inFS.close();

        // print word counts & backup results
        writeSectionBackupLabel("LOG TIME: ");
        for (const auto& pair : wordCounts)
        {
            cout << setw(15) << left << pair.first  << " " << string(pair.second, '*') << endl;
            writeToBackup(pair.first, pair.second);
        }
}

// Loop through menu options array and print options
void displayMenu()
{
    int size = sizeof(menuOptions) / sizeof(menuOptions[0]); // Calculate array size
    for (int i = 0; i < size; i++)
    {
        cout << menuOptions[i] << endl;
    }
}

// return instances of provided word as an integer
int getInstancesOfWord(string userWord)
{
    ifstream inFS; // input file stream
    int wordFrequences = 0;
    string currentWord = "";
    inFS.open(inputFile);
    if (!inFS.is_open())
    {
        cout << "Error: Could not open " << inputFile << "." << endl;
    }
    else
    {
        while (!inFS.eof())
        {
            inFS >> currentWord;
            if (!inFS.fail())
                {
                    if(currentWord == userWord)
                    {
                        ++wordFrequences;
                    }
                }
        }
    }
    inFS.close();
    return wordFrequences;
}

void writeToBackup(string userItem, int itemCount)
{
    // create an output stream object
    ofstream outFS;
    // open the file in append mode
    outFS.open(outputFile, ios_base::app);
    // verify if file was opened
    if (!outFS.is_open())
    {
        // DO NOT PROCEED to write to file; used 7.2 example which did not use try/catch; this works too
        cout << "ERROR: Writing to output file: " << outputFile << "." << endl;
    }
    else
    {
        outFS << userItem << " "<< itemCount << endl;
        outFS.close();
    }
}

// For sectioning the Backup
void writeSectionBackupLabel(string label)
{
    auto currentTime = chrono::system_clock::now(); // get current time
    time_t printableTime = chrono::system_clock::to_time_t(currentTime); // convert it to printable time
    // create an output stream object
    ofstream outFS;
    // open the file in append mode
    outFS.open(outputFile, ios_base::app);
    // verify if file was opened
    if (!outFS.is_open())
    {
        // DO NOT PROCEED to code that writes to file
        cout << "ERROR: Writing to output file: " << outputFile << "." << endl;
    }
    else
    {
        outFS << label << ctime(&printableTime);
        outFS.close();
    }
}

